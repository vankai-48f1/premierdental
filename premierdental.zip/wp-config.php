<?php
define('WP_AUTO_UPDATE_CORE', 'minor');
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'nhakh802_premierdental' );

/** MySQL database username */
define( 'DB_USER', 'nhakh802_premierdental' );

/** MySQL database password */
define( 'DB_PASSWORD', 'pfxpGypfxpGyr8GV^qr8GV^q' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '~bWQf;p%`#-)>U0Ae6wQNbx]ckD}/a<`(Oo*_CgscsSUQ9JOk53 uPC[p,- 7P`C' );
define( 'SECURE_AUTH_KEY',  'B^A=aUP :cSs1]@n42.@{:S:a&I4^YuZ]r%N#T+v6R?4Q~fkhKkeV5~vN/684G|U' );
define( 'LOGGED_IN_KEY',    'WfGWX#Z2C/z.7.(i!M.)zKO~F+T.&PD>^dGhoP/ENKgL]T/sH9IA9_RUd(tH^,0h' );
define( 'NONCE_KEY',        '!tJ(@^Bfp%O :T`goA<~-#JLJ(9&)RMt#vN3v(.ZP.t_H}d-FBSr,9GG bS]E;@!' );
define( 'AUTH_SALT',        '4j?.43t:NZ9ZLS%fg-xC/4T*yLyq{5[Hg>QvXO11FQ( L`; IB-G/x)*(K]RKSu6' );
define( 'SECURE_AUTH_SALT', '+:;DuZ2q0:{I+ pi|~H)zmQo*fMm]#A)4R,SJ/Wn}h%+`]jA$:]}Hma{tqzm.OEO' );
define( 'LOGGED_IN_SALT',   '`ik!%&/(6<3h 11?T|JT$<D$Z&E@TAf1Ag$T<ZoTcU0w,MO)YX(DUs*V[s=joaUL' );
define( 'NONCE_SALT',       '8aK[=4bMLC3-%_M~R2{(y8mTpy*c*[:!hV5#-q2(TVX|XT&}#y9{souoWg|QnN1>' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
